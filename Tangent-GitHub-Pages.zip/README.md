# Tangent — AI Course Teacher

Tangent is a browser-based AI course teacher. This repository is configured to build and deploy its static frontend to GitHub Pages.

## GitHub Pages deployment

1. In the repository, open **Settings → Pages**.
2. Under **Build and deployment**, choose **GitHub Actions** as the source.
3. Push to `main` (or run **Deploy Tangent to GitHub Pages** from the Actions tab).
4. Open `https://jasonhuanggeorgia-cloud.github.io/Tangent/` after the workflow succeeds.

The workflow builds the Vite app and publishes `dist/`. The Vite base path is set for this repository.

## AI backend requirement

GitHub Pages serves static assets only. It cannot run the Vite development API middleware in `vite.config.ts`, and an AI provider secret must never be placed in frontend code. The current frontend calls a Supabase Edge Function, but the included `supabase/functions/server/index.tsx` only implements a health check; it does not yet implement the `generate-course` or `generate-lesson` endpoints. Deploy and configure a secure Edge Function implementing those endpoints and set appropriate CORS/origin restrictions before expecting live AI generation to work. Never commit provider secrets.

## Development

- Node.js 22
- `npm install`
- `npm run dev`
- `npm run build`
